(function(){var P$=Clazz.newPackage("java.awt.peer"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "LightweightPeer", null, null, 'java.awt.peer.ComponentPeer');

C$.$clinit$=2;
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-07-24 19:16:38 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
