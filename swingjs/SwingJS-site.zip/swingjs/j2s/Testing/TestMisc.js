(function(){var P$=Clazz.newPackage("Testing"),p$1={},I$=[[0,'test.TestMisc']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "TestMisc");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['Z',['b'],'C',['c'],'D',['d'],'F',['f'],'I',['i'],'S',['s']]]

Clazz.newMeth(C$, 'test',  function () {
var s="test";
var ii=$I$(1).i;
var ifi=2;
}, p$1);

C$.$static$=function(){C$.$static$=0;
C$.i=1;
C$.s="test";
C$.f=2;
C$.d=3;
C$.c="c";
C$.b=true;
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v1');//Created 2023-11-09 17:25:17 Java2ScriptVisitor version 5.0.1-v1 net.sf.j2s.core.jar version 5.0.1-v1
